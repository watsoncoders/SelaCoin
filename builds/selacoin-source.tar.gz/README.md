Development moved to https://gitlab.com/blacknet-ninja

https://selacoin.org/ aims to continue on SelaCoin chain.
